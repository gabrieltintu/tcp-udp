#include <iostream>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <vector>
#include <unordered_map>
#include <fstream>
#include <vector>
#include <poll.h>
#include "helpers.h"
#include "common.h"

// using namespace std;

std::ofstream fout("file_server.out");

#define MAX_LEN 100


int main(int argc, char *argv[]) {
    setvbuf(stdout, NULL, _IONBF, BUFSIZ);

	// check arg
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <PORT>\n";
        return EXIT_FAILURE;
    }

	std::vector<pollfd> poll_fds;
	int num_sockets = 1;
	int rc;
	// set port
    uint16_t port;
	rc = sscanf(argv[1], "%hu", &port);
	DIE(rc != 1, "Given port is invalid");
	fout << "server: " << port << "\n";
	fout.flush();

    // create TCP socket
	int sock_tcp;
	struct sockaddr_in serv_addr;
	socklen_t socket_len = sizeof(struct sockaddr_in);


	// creare socket pt TCP + bind + listen
	sock_tcp = socket(AF_INET, SOCK_STREAM, 0);

	// Facem adresa socket-ului reutilizabila, ca sa nu primim eroare in caz ca
	// rulam de 2 ori rapid
	const int enable = 1;
	if (setsockopt(sock_tcp, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
		perror("setsockopt(SO_REUSEADDR) failed");
	

	memset(&serv_addr, 0, socket_len);
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(port);
	serv_addr.sin_addr.s_addr = INADDR_ANY;

    DIE(sock_tcp < 0, "eroare socket - tcp\n");
	rc = bind(sock_tcp, (struct sockaddr *) &serv_addr, sizeof(serv_addr));
    DIE(rc < 0, "eroare bind - tcp\n");
    rc = listen(sock_tcp, SOMAXCONN / 4);
    DIE(rc < 0, "eroare listen - udp\n");
	

	// Adaugam noul file descriptor (socketul pe care se asculta conexiuni) in
	// multimea poll_fds
	pollfd listen_poll_fd;
    listen_poll_fd.fd = sock_tcp;
    listen_poll_fd.events = POLLIN;

    // Push back the listen pollfd structure into the vector
    poll_fds.push_back(listen_poll_fd);

    // std::cout << "Server is running on port " << port << std::endl;
	fout << "inainte de while\n";
	fout.flush();

	pollfd stdin_poll_fd;
	stdin_poll_fd.fd = 0;
	stdin_poll_fd.events = POLLIN;
	poll_fds.push_back(stdin_poll_fd);
	num_sockets++;
	
    bool running = true;
    int clientSocket;
	int connfd1 = -1;
	fout << "ceplm\n";
	fout.flush();
	fout << "poll_fd size: " << poll_fds.size() << "\n";
	fout.flush();


	struct chat_packet received_packet;

    while (running) {
		// exit command 
		char buff[MAX_LEN];
		
		fout << "aici\n";
		fout.flush();
		rc = poll(poll_fds.data(), poll_fds.size(), -1);
   	 	DIE(rc < 0, "poll");
		fout << "dupa poll\n";
		fout.flush();
		for (int i = 0; i < poll_fds.size(); i++) {
			fout << "in for>\n";
			fout.flush();
			if (poll_fds[i].revents & POLLIN) {
				if (poll_fds[i].fd == 0) {
					fgets(buff, MAX_LEN - 1, stdin);
		
					fout << buff;
					fout.flush();
				
					if (strcmp(buff, "exit\n") == 0) {
						fout << "a gasit exit!\n";
						fout.flush();
						for (int i = poll_fds.size() - 1; i >= 0; i--) {
							close(poll_fds[i].fd);
						}
						return 0;
					}
				} else if (poll_fds[i].fd == sock_tcp) {
					// Am primit o cerere de conexiune pe socketul de listen, pe care
					// o acceptam
					fout << "a gasit o conexiune\n";
					struct sockaddr_in cli_addr;
					socklen_t cli_len = sizeof(cli_addr);
					const int newsockfd =
						accept(sock_tcp, (struct sockaddr *)&cli_addr, &cli_len);
					DIE(newsockfd < 0, "accept");

					// Adaugam noul socket intors de accept() la multimea descriptorilor
					// de citire
					pollfd new_poll_fd;
					new_poll_fd.fd = newsockfd;
					new_poll_fd.events = POLLIN;

					// Add the new pollfd structure to the vector
					poll_fds.push_back(new_poll_fd);

					// Increment the number of sockets
					int num_sockets = poll_fds.size();

					char buffer[256];
					// Receive data in a loop until a newline character is received
					ssize_t bytes_received;
					int rc = recv_all(newsockfd, &received_packet, sizeof(received_packet));
          			DIE(rc < 0, "recv");
					
					fout << "ce primesc din subscriber: " << received_packet.message << "\n";
					fout.flush();

					// if (bytes_received == -1) {
					// 	std::cerr << "Error receiving client info from client\n";
					// 	continue;
					// }

					
					// std::string new_id = std::string(buff);
					std::cout << "New client " << received_packet.message << " connected from " << port << "\n";
				}
			}
		}

    }

    // Close socket

    return 0;
}
