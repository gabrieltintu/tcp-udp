#include <iostream>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <fstream>
#include "helpers.h"
#include "common.h"

std::ofstream out("file_subscriber.out");

int main(int argc, char *argv[]) {
    if (argc != 4) {
        std::cerr << "Usage: " << argv[0] << " <ID_CLIENT> <IP_SERVER> <PORT_SERVER>\n";
        return EXIT_FAILURE;
    }

    // Parse command-line arguments
    std::string clientId = argv[1];
    std::string serverIp = argv[2];
    int serverPort = std::atoi(argv[3]);
    int rc;
    // Create TCP socket
    int tcpSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (tcpSocket == -1) {
        std::cerr << "Error creating TCP socket\n";
        return EXIT_FAILURE;
    }

    // Initialize server address structure
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(serverPort);
    inet_pton(AF_INET, serverIp.c_str(), &serverAddr.sin_addr);
    out << "client id: " << clientId << "\n";
    // Connect to the server
    rc = connect(tcpSocket, (struct sockaddr*) &serverAddr, sizeof(serverAddr));
    DIE(rc < 0, "connect");

    struct chat_packet sent_packet;

    sent_packet.len = clientId.size() + 1;
    strcpy(sent_packet.message, clientId.c_str());

    rc = send_all(tcpSocket, &sent_packet, sizeof(sent_packet));    
    DIE(rc < 0, "send");

    // Main loop to receive commands from user
    while (true) {
        std::string input;
        std::cout << "Enter command (subscribe/unsubscribe/exit): ";
        std::getline(std::cin, input);

        // Send command to server
        // rc = send(tcpSocket, input.c_str(), input.length(), 0);
        // if (rc == -1) {
        //     std::cerr << "Error sending command to server\n";
        //     break;
        // }

        // Exit loop if "exit" command is received
        if (input == "exit") {
            break;
        }
    }

    // Close TCP socket
    close(tcpSocket);

    return EXIT_SUCCESS;
}
